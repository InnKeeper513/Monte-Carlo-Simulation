import javax.swing.*;

/**
 * Created by jerry on 2017/8/14.
 */
public class mainClass {

    public static void main(String[]args){
        DrawFrame df = new DrawFrame();
        df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        df.setVisible(true);
        df.setResizable(false);
    }
}
